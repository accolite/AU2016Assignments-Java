package com.accolite.xmlJAXB;

import java.io.FileOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

public class Marshalling {
	public static void main(String[] args) throws Exception{  
		
		JAXBContext contextObj = JAXBContext.newInstance(Address.class);  
		Marshaller marshallerObj = contextObj.createMarshaller();  
		marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);  
		
		Address que=new Address("pawan","pawan.prakash305@gmail.com","8019463072");  
		marshallerObj.marshal(que, new FileOutputStream("C:\\Users\\Pawan Prakash\\Desktop\\afterMarshalling.xml"));  
		}
}
