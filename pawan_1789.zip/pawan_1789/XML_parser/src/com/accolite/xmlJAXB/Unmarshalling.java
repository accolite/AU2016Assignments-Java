package com.accolite.xmlJAXB;
import java.io.File;  
import java.util.List;  
  
import javax.xml.bind.JAXBContext;  
import javax.xml.bind.JAXBException;  
import javax.xml.bind.Unmarshaller;  
   
public class Unmarshalling {

	public static void main(String args[]) {

	 
		   
		     try {  
		   
		        File file = new File("C:\\Users\\Pawan Prakash\\Desktop\\beforeUnmarshalling.xml");  
		        JAXBContext jaxbContext = JAXBContext.newInstance(Address.class);  
		   
		        Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();  
		        Address que= (Address) jaxbUnmarshaller.unmarshal(file);  
		          
		        System.out.println(que.getName()+"\n"+que.getEmail() + "\n" + que.getPhone());  
		        //System.out.println("Answers:");  
		       
		   
		      } catch (JAXBException e) {  
		        e.printStackTrace();  
		      }  
		   
		
	}
}
