package com.accolite.au.VideoPortal.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.accolite.au.VideoPortal.model.User;
import com.accolite.au.VideoPortal.model.Video;
@Repository
public class ApprovalDAO {
 @Autowired
 private JdbcTemplate jdbcTemplate;
 public List<Video> fetchGroupRelatedVideo(User user) {
  List<Video> videos = new ArrayList<>();
  // TODO Auto-generated method stub
  String query="select * from VideoTable as vT inner join GroupVideoTable as gvt on vT.video_id=gvt.video_id inner join GroupUserTable as gut on gut.group_id=gvt.video_id where gut.user_id="+user.getUser_id()+"and vT.statusflag=0";
  return jdbcTemplate.query(query, new ResultSetExtractor<List<Video>>() {

   public List<Video> extractData(ResultSet rs) throws SQLException, DataAccessException {

    while (rs.next()) {
     Video video = new Video();
     video.setVideo_id(rs.getInt("video_id"));
     video.setTitle(rs.getString("Title"));
     video.setTopic(rs.getString("Topic"));
     video.setApproval_id(rs.getInt("Approval_id"));
     video.setEvent_id(rs.getInt("event_id"));
     video.setPrivacy(rs.getString("Privacy"));
     video.setUser_id(rs.getInt("user_id"));
     video.setStatusFlag(rs.getInt("statusFlag"));
     video.setUrl(rs.getString("url"));
     videos.add(video);
    }
    return videos;

   }
  });
 }

 public List<Video> fetchAllVideo(User user) {
  List<Video> videos = new ArrayList<>();
  // TODO Auto-generated method stub
  String query="select * from VideoTable as vT where vT.statusflag=0";
  return jdbcTemplate.query(query, new ResultSetExtractor<List<Video>>() {

   public List<Video> extractData(ResultSet rs) throws SQLException, DataAccessException {

    while (rs.next()) {
     Video video = new Video();
     video.setVideo_id(rs.getInt("video_id"));
     video.setTitle(rs.getString("Title"));
     video.setTopic(rs.getString("Topic"));
     video.setApproval_id(rs.getInt("Approval_id"));
     video.setEvent_id(rs.getInt("event_id"));
     video.setPrivacy(rs.getString("Privacy"));
     video.setUser_id(rs.getInt("user_id"));
     video.setStatusFlag(rs.getInt("statusFlag"));
     video.setUrl(rs.getString("url"));
     videos.add(video);
    }
    return videos;

   }
  });
 }

}