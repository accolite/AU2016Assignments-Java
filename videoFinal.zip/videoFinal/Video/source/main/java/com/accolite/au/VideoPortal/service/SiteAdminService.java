package com.accolite.au.VideoPortal.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accolite.au.VideoPortal.DAO.SiteAdminDAO;
import com.accolite.au.VideoPortal.DAO.UserDAO;
import com.accolite.au.VideoPortal.model.Group;
import com.accolite.au.VideoPortal.model.User;

@Service
public class SiteAdminService {
	@Autowired
	private SiteAdminDAO jdbc;

	@Autowired
	 private UserDAO user_jdbc;
	
	/*public boolean makeSiteAdmin(int user_id) {
		if (jdbc.RetrieveSiteAdmin(user_id) == null) {
			User user = new User();
			user.setUser_id(user_id);
			int result = jdbc.AddAdmin(user);
			if (result == 1)
				return true;
			else
				return false;
		}
		return false;

	}*/
	
	public List<Group> listGroupsForUser(String email) {
		  // TODO Auto-generated method stub
		  User user=user_jdbc.RetrieveUser(email);
		  List<Group> groups=new ArrayList<>();
		  groups=user_jdbc.listGroups(user);
		  return groups;
		 }
	
	public List<Group> listGroups() {
		  // TODO Auto-generated method stub
		  List<Group>groups=new ArrayList<>();
		  groups=jdbc.listAllGroups();
		  return groups;
		 }
	
	public boolean makeSiteAdmin(String name) {
		  if (jdbc.RetrieveSiteAdminExistsAsUser(name) != null) {
		   System.out.println(name);
		   User user = new User();
		   user.setFirstname(name);
		   user.setUser_id(jdbc.getUserId(user));
		   int result = jdbc.AddAdmin(user);
		   if (result == 1)
		    return true;
		   else
		    return false;
		  }
		  return false;

		 }

	/*public boolean deleteSiteAdmin(int user_id) {
		if (jdbc.RetrieveSiteAdmin(user_id) != null) {
			User user = new User();
			user.setUser_id(user_id);
			int result = jdbc.DeleteAdmin(user);
			if (result == 1)
				return true;
			else
				return false;
		}
		return false;

	}*/
	
	public boolean deleteSiteAdmin(String name) {
		  if (jdbc.RetrieveSiteAdmin(name) != null) {
		   User user = new User();
		   user.setFirstname(name);
		   //user.setUser_id(user_id);
		   user.setUser_id(jdbc.getUserId(user));
		   int result = jdbc.DeleteAdmin(user);
		   if (result == 1)
		    return true;
		   else
		    return false;
		  }
		  return false;

		 }
	
	 public boolean isGroupAdmin(User user)
	  {
	   return jdbc.isGroupAdmin(user);
	  }
	
	//called by SiteAdminController to create Group
	 //Checks whether group name already exists and returns true or false.
	 public boolean createGroup(String group_name,String admin_name)
	 {
	  if(!jdbc.groupAlreadyExists(group_name)){
	   //Now to create Group and also the Admin
	   Group group = new Group();
	   User user = new User();
	   group.setName(group_name);
	   //Through the name try to get user_ID FROM DB & assign this id to the group admin column.
	   //user.setUser_id(1);
	   int test1 = jdbc.CreateGroup(group);//If test1 is 1 then group is created.
	   //Now get the group id of newly created group and admin id from user table
	   user.setFirstname(admin_name);
	   user.setUser_id(jdbc.getUserId(user));
	   group.setGroup_id(jdbc.getGroupId(group));
	   int test2 = jdbc.CreateGroupAdmin(group,user);
	   if(test1 ==1 && test2 == 1)
	   {
	    return true;//Group Created and Admin Added.
	   }
	    
	   return false;//Group NOT created
	  }
	  
	  return false;//Group Not created.
	 }
	 
	 public User isSiteAdmin(User user) {
		 
		 return jdbc.isSiteAdmin(user);
	 }

}
