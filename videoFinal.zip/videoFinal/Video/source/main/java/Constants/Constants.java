package Constants;

public class Constants {
	public static final String rootPath="http://localhost:8081/VideoPO/";
}
