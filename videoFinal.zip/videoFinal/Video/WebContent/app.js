var app=angular.module('VideoPortal',['ngRoute']);
app.controller('AppController',['$scope','$http','$sce',function($scope,$http,$sce){
	$scope.UserName='';
	$scope.start=function(){
		
		$scope.typeuser();
		$scope.detect();
		$scope.getAllVideos();
		$scope.getGrpNames();
		$scope.admin=true;
		$scope.user=false;
		$scope.grpadmin=false;
		$scope.infoOfGrp=false;
		$scope.addAdmin=false;
		$scope.siteAdmin=false;
		$scope.grpAdmin=false;
		$scope.crtGrp=false;
		$scope.crtEvt=false;
		$scope.grpvid=false;
		$scope.addnames=[{name:""}];
		$scope.apprvid=false;
		$scope.vid_grp={value:''};
		
	};
	
	
	$scope.signOut = function(){
        var auth2 = gapi.auth2.getAuthInstance();
        auth2.signOut().then(function () {
          console.log('User signed out.');
          window.location.href = 'http://localhost:8081/VideoPO/';
        });
      }
	
	$scope.detect=function(){
		$http({
			method:'GET',
			url:'spr/detectUser',
		}).then(function successCallback(response){
			 $scope.UserName = response.data;
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	};
	
	$scope.typeuser=function(){
		$http({
			method:'GET',
			url:'spr/isSiteAdmin',
		}).then(function successCallback(response) {
			
			$scope.integer = response.data;
			if($scope.integer==1){
				$scope.admin=true;
				$scope.user=false;
				$scope.grpadmin=false;
				console.log('admin');
			}else if($scope.integer==2){
				$scope.admin=false;
				$scope.user=false;
				$scope.grpadmin=true;
				console.log('gradmin');
			}else{
				$scope.admin=false;
				$scope.user=true;
				$scope.groupspecvid();
				$scope.grpadmin=false;
				console.log('user');
			}
			console.log("msc");
		}, function errorCallback(response) {
			console.log("failed");
			console.log(response.statusText);
		});
	};
	
	
	$scope.submitusername = function(group_name) {
		var x = "";
		for(var i = 0; i < $scope.addnames.length-1; i++) {
			x = x + $scope.addnames[i].name + ',';
		}
		x = x + $scope.addnames[i].name; 
		
		//;console.log(username[0].username.name);
//		var x1 = {"users":[username]};
		$http({
	        method : 'GET',
	        url : 'spr/addMembers?x='+x+'&group_name='+group_name,
	    }).then(function successCallback(response) {
	        console.log("yey adding members");
	    }, function errorCallback(response) {
	        console.log(response.statusText);
	    });
	};
	
	 $scope.addEvent=function(event_name, date_of_event)
	 {
		 $http({
	         method : 'GET',
	         url : 'spr/addEvent?event_name='+ event_name+'&date_of_event='+date_of_event,
	     }).then(function successCallback(response) {
	    	 $scope.searchResult = response.data;
	     }, function errorCallback(response) {
	         console.log(response.statusText);
	     });
	 }
	
	 $scope.submitgrp = function(cgroup_name, group_admin) {

		 $http({
	         method : 'GET',
	         url : 'spr/createGroup?group_name='+cgroup_name+'&group_admin='+group_admin
	     }).then(function successCallback(response) {
	    	
	     }, function errorCallback(response) {
	         console.log(response.statusText);
	     });
	 };
	 
	 $scope.addVideo = function(video_url,title,topic,event,group_name) {
		 var k = $scope.group_name;
		 $http({
	         method : 'GET',
	         url : 'spr/addVideo?video_url='+ video_url+'&title='+title+'&topic='+topic+'&event='+event+'&group_name='+group_name
	     }).then(function successCallback(response) {
	    	 $scope.searchResult = response.data;
	    	 console.log("yey video");
	     }, function errorCallback(response) {
	         console.log(response.statusText);
	     });
	 }
	
	$scope.getAllVideos=function(){
		$http({
			method:'GET',
			url:'spr/getPublicVideo',
		}).then(function successCallback(response) {
			
			$scope.videos = response.data;
			console.log("Successd");
		}, function errorCallback(response) {
			console.log("failed");
			console.log(response.statusText);
		});
	};

	$scope.getGrpNames=function(){
		$http({
			method:'GET',
			url:'spr/listGroup',
		}).then(function successCallback(response){
			$scope.grpNames = response.data;
			console.log("grp success charan");
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	}

	$scope.groupinfo=function(dt){
		$scope.groupvid(dt);//infoOfGrp
	}

	$scope.groupvid=function(dt){
		$http({
			method:'GET',
			url:'spr/listGrpVideo?group_id='+dt,
		}).then(function successCallback(response){
			$scope.grpVideos = response.data;
			$scope.grpvid=true;
			$scope.apprvid=false;
			console.log("grp success");
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	};

	
	$scope.addusername = function() {
		$scope.addnames.push({name:""});
		console.log("in push");
	}
	
	$scope.groupspecvid=function(){
		$http({
			method:'GET',
			url:'spr/listGroupForUser',
		}).then(function successCallback(response){
			$scope.usergrps = response.data;
			console.log("acco");
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	};
	
	$scope.addsiteadmin=function(name){
		$http({
			method:'GET',
			url:'spr/makeAdmin?name='+name,
		}).then(function successCallback(response){
			console.log("site admin");
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	};
	
	$scope.setpre=function(){
		$scope.apprvid=false;
		$scope.grpvid=false;
		console.log('yup');
		$scope.getAllVideos();
	};
	
	$scope.fetch=function(){
		$http({
			method:'GET',
			url:'spr/FetchVideosForApproval',
		}).then(function successCallback(response){
			$scope.apprvids = response.data;
			$scope.apprvid=true;
			console.log("Fetching vids");
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	};
	
	$scope.approve=function(id){
		$http({
			method:'GET',
			url:'spr/ApproveVideo?video_id='+id,
		}).then(function successCallback(response){
			$scope.apprvids = response.data;
			console.log("approval done");
			$scope.fetch();
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	};
	

	$scope.reject=function(id){
		$http({
			method:'GET',
			url:'spr/RejectVideo?video_id='+id,
		}).then(function successCallback(response){
			$scope.apprvids = response.data;
			console.log("reject done");
			$scope.fetch();
		}, function errorCallback(response) {
			console.log(response.statusText);
		});
	};

}]);


